# fbwV2

>>>fbwFasy.py have LESS PASSWORDS and so it is FAST


>>>fbwLazy.py have MORE PASSWORDS and is SLOW 


>>>TO INSTALL RUN THESE  COMMANDS 


>>>([USE ALL COMMANDS FOR THE FIRST TIME AFTER THAT YOU CAN LAUNCH SCRIPT BY EITHER OF THE LAST 2 COMMANDS ]




$ apt update

$ apt upgrade

$ apt install python

$ apt install python2

$ apt install git

$ git clone https://github.com/faizanwahla/fbwV2.git

$ pip2 install requests mechanize



>>>TO USE FAST SCRIPT


$ cd fbwV2 && python2 fbwFast.py





>>>TO USE LAZY SCRIPT


$ cd fbwV2 && python2 fbwLazy.py



>>>passlist is also added in this package 
